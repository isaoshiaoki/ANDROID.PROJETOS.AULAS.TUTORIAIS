package br.com.thiengo.retrofitexample.domain;

import br.com.thiengo.retrofitexample.util.Obj;

/**
 * Created by viniciusthiengo on 10/11/15.
 */
public class Brand extends Obj {
    public Brand() {
    }

    public Brand(String name, String pathImg) {
        super(name, pathImg);
    }
}

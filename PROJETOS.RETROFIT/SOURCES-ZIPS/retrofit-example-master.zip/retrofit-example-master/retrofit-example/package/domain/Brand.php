<?php
/**
 * Created by PhpStorm.
 * User: viniciusthiengo
 * Date: 10/11/15
 * Time: 10:28 PM
 */

class Brand extends Obj {
    public function __construct( $name, $pathImg ){
        parent::__construct($name, $pathImg);
    }
}